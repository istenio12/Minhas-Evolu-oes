using System;

class Program
{
    public static void Main(string[] args)
    {
        decimal numero_de_sapato =1;
        decimal ano_de_nascimento =1;
        Decimal ano_atual =1;

      try
        {
        if(numero_de_sapato >=1)
      Console.WriteLine("vou te ajudar a descobrir sua idade, digite o numero do seu calçado seguido de (,00)");
         numero_de_sapato = decimal.Parse(Console.ReadLine());
     
        }
        catch (Exception)
        {
            Console.WriteLine("por favor digite um umero valido");
          Console.ReadKey();
        }
            
    
        Console.WriteLine("agora digite o ano que você nasceu");
        try
        {
            ano_de_nascimento = Convert.ToDecimal(Console.ReadLine());
        }
        catch (Exception)
        {
            Console.WriteLine("por favor digite um umero valido");
          Console.ReadKey();
        }
        Console.WriteLine("informe o ano em que estamos");
        try
        {
            ano_atual = Convert.ToDecimal(Console.ReadLine());
        }
        catch (Exception)
        {
            Console.WriteLine("por favor digite um umero valido");
          Console.ReadKey();
        }

        Decimal resultado = numero_de_sapato - ano_de_nascimento + ano_atual;

        Console.WriteLine("agora os ultimos dois nuero é a idade que tem hoje ou ira fazer !");

        Console.WriteLine(resultado);

      Console.WriteLine("Espero que tenha gostado da brincadeira !");
      Console.ReadKey();



    }
}